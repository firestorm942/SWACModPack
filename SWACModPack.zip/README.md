SWACModPack
